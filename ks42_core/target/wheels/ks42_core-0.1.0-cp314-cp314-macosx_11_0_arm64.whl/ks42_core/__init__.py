from .ks42_core import *

__doc__ = ks42_core.__doc__
if hasattr(ks42_core, "__all__"):
    __all__ = ks42_core.__all__