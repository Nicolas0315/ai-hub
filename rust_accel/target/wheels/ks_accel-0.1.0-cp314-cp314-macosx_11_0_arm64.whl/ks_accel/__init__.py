from .ks_accel import *

__doc__ = ks_accel.__doc__
if hasattr(ks_accel, "__all__"):
    __all__ = ks_accel.__all__